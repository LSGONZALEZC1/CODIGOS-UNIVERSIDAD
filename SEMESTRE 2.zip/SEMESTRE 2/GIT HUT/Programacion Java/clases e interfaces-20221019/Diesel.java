public class Diesel extends Motor {

    public Diesel(int potencia) {
        super(potencia, "Diesel");
    }
    
}
