public interface In_Cazador{
    public String Cazar();
}