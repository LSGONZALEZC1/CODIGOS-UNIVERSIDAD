public class fechaGrado extends Estudiante {
    
    protected String fecha_grado;

    public String getFecha_grado() {
        return fecha_grado;
    }

    public void setFecha_grado(String fecha_grado) {
        this.fecha_grado = fecha_grado;
    }

}
