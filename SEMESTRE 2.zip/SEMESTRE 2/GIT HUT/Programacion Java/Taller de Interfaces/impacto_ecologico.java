public interface impacto_ecologico {

   float Calcular_impacto(double impacto);
    
}
