public class Doctorado extends fechaGrado {
    
    protected String grupo_investigacion;

    public String getGrupo_investigacion() {
        return grupo_investigacion;
    }

    public void setGrupo_investigacion(String grupo_investigacion) {
        this.grupo_investigacion = grupo_investigacion;
    }

    @Override
    public String toString(){
        return "";
    }

    public void setCodigo(String string) {
    }

}
