public interface Movil {
    public void arrancar();
    public void acelerar(int vel);
    public void frenar(int vel);
    public void detener();
}
