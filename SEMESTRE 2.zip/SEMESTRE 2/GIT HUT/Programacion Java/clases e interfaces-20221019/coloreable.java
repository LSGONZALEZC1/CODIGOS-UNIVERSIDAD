public interface coloreable {
    void lijar();
    void pintar(String color);
    void encerar();
}
