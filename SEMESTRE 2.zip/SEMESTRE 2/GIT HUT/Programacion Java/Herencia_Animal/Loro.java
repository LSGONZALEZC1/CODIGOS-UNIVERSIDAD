public class Loro extends Animal{
  
    public Loro(){
      
    }
  }