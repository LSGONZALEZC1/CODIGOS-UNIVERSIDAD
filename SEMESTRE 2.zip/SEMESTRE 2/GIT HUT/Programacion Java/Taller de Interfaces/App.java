import java.util.Scanner;

public class App {

    public static void main(String[] args){

        try (Scanner teclado = new Scanner(System.in)){
            
            int opcion;

              System.out.println("\nElige una opcion para registrar impacto ecologico\n");
              System.out.println("1. Edificio");
              System.out.println("2. Automovil");
              System.out.println("3. Bicicleta");
              System.out.println("4. Salir\n");

              opcion=teclado.nextInt();
              teclado.nextLine();

              switch (opcion) {
                  case 1:
                    regisgrar_edificio();
                    break;

                  case 2:
                    regisgrar_auto();
                    break;

                  case 3:
                    regisgrar_bicicleta();
                    break;

                  case 4:
                    break;
            
                  default:
                    break;
                }

            teclado.close();

        }

    }

    public static void regisgrar_edificio(){
        Scanner teclado =new Scanner(System.in);
        Edificio.e1=new Edificio();

        System.out.println("\nIngrese la cantidad de metros cuadrados que usa el edificio.");
        int Area=teclado.nextInt();

        System.out.println("\nIngrese el número de ascensores con los que cuenta el edificio.");
        int Ascensores=teclado.nextInt();

        System.out.println("\nIngrese el número de generadores (plantas eléctricas) con las que cuenta el edificio.");
        int Generadores_diesel=teclado.nextInt();

        e1.setArea(Area);
        e1.setAscensores(Ascensores);
        e1.setGeneradores_diesel(Generadores_diesel);

    }

    public static void regisgrar_auto(){

        Scanner teclado =new Scanner(System.in);
        Auto.a1=new Auto();

        System.out.println("\nIngrese el kilometraje recorrido.");
        int Kilometraje=teclado.nextInt();

        System.out.println("\nIngrese el tipo de motor: diesel, gasolina o electrico.");
        String Motor=teclado.nextLine();

        a1.setKilometraje_recorrido(Kilometraje);
        a1.setMotor(Motor);

    }

    public static void regisgrar_bicicleta(){

        Scanner teclado =new Scanner(System.in);
        Bicicleta.b1=new Bicicleta;

        System.out.println("\nIngrese el kilometraje recorrido.");
        int Kilometraje=teclado.nextInt();
        
        b1.setKilometraje_recorrido(Kilometraje);


    }
    
}
