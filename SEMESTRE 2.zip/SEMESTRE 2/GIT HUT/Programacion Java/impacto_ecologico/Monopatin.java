public class Monopatin extends Patineta{

    public Monopatin(int potencia, int kilometros) {
        super(potencia, kilometros);
    }
    
}
