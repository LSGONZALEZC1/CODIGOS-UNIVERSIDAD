public class Gato extends Mamifero{
  
    public Gato(){
      
    }
    
  }
  
  //solo esta el constructor en esta clase