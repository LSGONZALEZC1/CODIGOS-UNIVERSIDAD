public class Maestria extends fechaGrado {
    
    protected String proyecto_investigacion;

    public String getProyecto_investigacion() {
        return proyecto_investigacion;
    }

    public void setProyecto_investigacion(String proyecto_investigacion) {
        this.proyecto_investigacion = proyecto_investigacion;
    }

    @Override
    public String toString(){
        return "";
    }

    public void setCodigo(String string) {
    }

}
