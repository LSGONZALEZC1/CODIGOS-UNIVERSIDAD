public class Obj_Titi extends Cla_Mamifero{

    public Obj_Titi(String nom, String gen, String espe, String proceden, double peso, int tiempo_de_encubacion) {
        super(nom, gen, espe, proceden, peso, tiempo_de_encubacion);
    }


    
    
}